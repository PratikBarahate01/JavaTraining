package com.foodhub.customersubscriberservice.repository;

import com.foodhub.customersubscriberservice.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
