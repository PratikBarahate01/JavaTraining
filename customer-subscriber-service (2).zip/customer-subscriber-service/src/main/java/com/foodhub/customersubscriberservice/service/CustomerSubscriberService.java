package com.foodhub.customersubscriberservice.service;

import com.foodhub.customersubscriberservice.dto.CustomerDTO;
import com.foodhub.customersubscriberservice.entity.Customer;
import com.foodhub.customersubscriberservice.repository.CustomerRepository;
import com.foodhub.customersubscriberservice.repository.SubscriberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class CustomerSubscriberService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private SubscriberRepository subscriberRepository;


    public Customer createCustomer(CustomerDTO customer) {

        customerRepository.save();
    }
}
