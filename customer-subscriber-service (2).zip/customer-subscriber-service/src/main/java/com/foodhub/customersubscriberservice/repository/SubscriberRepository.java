package com.foodhub.customersubscriberservice.repository;

import com.foodhub.customersubscriberservice.entity.Subscriber;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscriberRepository extends JpaRepository<Subscriber, Long> {
}
