package com.foodhub.customersubscriberservice.utility;

import org.springframework.stereotype.Component;

@Component
public class Utility {

    private PostDto convertToDto(Post post) {
        PostDto postDto = modelMapper.map(post, PostDto.class);
        postDto.setSubmissionDate(post.getSubmissionDate(),
                userService.getCurrentUser().getPreference().getTimezone());
        return postDto;
    }
}
