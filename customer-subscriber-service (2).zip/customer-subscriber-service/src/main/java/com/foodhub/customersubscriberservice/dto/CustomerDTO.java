package com.foodhub.customersubscriberservice.dto;

public class CustomerDTO {
}
