package com.foodhub.customersubscriberservice.entity;

public class Subscriber {
}
