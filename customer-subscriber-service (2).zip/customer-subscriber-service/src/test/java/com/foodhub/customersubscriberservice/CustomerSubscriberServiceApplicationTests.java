package com.foodhub.customersubscriberservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerSubscriberServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
